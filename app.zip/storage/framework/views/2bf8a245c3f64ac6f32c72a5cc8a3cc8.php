


<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Data Dokter</h1>

    <a href="<?php echo e(route('dokter.create')); ?>">+ Tambah Dokter</a>

    <?php if(session('success')): ?>
        <p style="color: green;">
            <?php echo e(session('success')); ?>

        </p>
    <?php endif; ?>

    <br><br>

    <table border="1" cellpadding="10" cellspacing="0">
        <thead>
            <tr>
                <th>No</th>
                <th>Kode Dokter</th>
                <th>Nama</th>
                <th>Spesialisasi</th>
                <th>Poli</th>
                <th>Telepon</th>
                <th>Status</th>
            </tr>
        </thead>

        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($doctor->doctor_code); ?></td>
                    <td><?php echo e($doctor->name); ?></td>
                    <td><?php echo e($doctor->specialization); ?></td>
                    <td><?php echo e($doctor->poli?->name ?? '-'); ?></td>
                    <td><?php echo e($doctor->phone ?? '-'); ?></td>
                    <td>
                        <?php if($doctor->is_active): ?>
                            Aktif
                        <?php else: ?>
                            Tidak Aktif
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7">Belum ada data dokter.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\THINKPAD\klinik-app\resources\views/dokter/index.blade.php ENDPATH**/ ?>