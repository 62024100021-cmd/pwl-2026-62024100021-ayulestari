
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Sistem Informasi Klinik'); ?></title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <style>
        body {
            background-color: #f5f7fb;
        }

        header {
            background-color: #0d6efd;
            color: white;
            padding: 20px 30px;
        }

        header h2 {
            margin: 0;
        }

        nav {
            background-color: white;
            padding: 12px 30px;
            border-bottom: 1px solid #ddd;
        }

        nav a {
            text-decoration: none;
            margin-right: 20px;
            color: #0d6efd;
        }

        main {
            padding: 30px;
        }

        footer {
            text-align: center;
            padding: 15px;
            color: #666;
        }
    </style>
</head>
<body>
    <header>
        <h2>Sistem Informasi Klinik</h2>
    </header>

    <nav>
        <a href="<?php echo e(url('/')); ?>">Dashboard</a>
        <a href="<?php echo e(route('pasien.index')); ?>">Pasien</a>
        <a href="<?php echo e(route('dokter.index')); ?>">Dokter</a>
        <a href="<?php echo e(route('poli.index')); ?>">Poli</a>
    </nav>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer>
        <p>Pemrograman Web Lanjut</p>
    </footer>
</body>
</html><?php /**PATH C:\Users\THINKPAD\klinik-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>