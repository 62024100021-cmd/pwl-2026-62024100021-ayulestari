

<?php $__env->startSection('title', 'Poli'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Data Poli</h1>

    <table border="1" cellpadding="10" cellspacing="0">
        <thead>
            <tr>
                <th>No</th>
                <th>Kode Poli</th>
                <th>Nama Poli</th>
                <th>Deskripsi</th>
                <th>Status</th>
                <th>Jumlah Dokter</th>
                <th>Dokter</th>
            </tr>
        </thead>

        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $polis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($poli->code); ?></td>
                    <td><?php echo e($poli->name); ?></td>
                    <td><?php echo e($poli->description ?? '-'); ?></td>
                    <td><?php echo e($poli->is_active ? 'Aktif' : 'Tidak Aktif'); ?></td>
                    <td><?php echo e($poli->doctors->count()); ?></td>
                    <td>
                        <?php $__empty_2 = true; $__currentLoopData = $poli->doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                            <?php echo e($doctor->name); ?><?php if(!$loop->last): ?>, <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                            Belum ada dokter
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7">Belum ada data poli.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\THINKPAD\klinik-app\resources\views/poli/index.blade.php ENDPATH**/ ?>