


<?php $__env->startSection('title', 'Tambah Dokter'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Tambah Dokter</h1>

    <?php if($errors->any()): ?>
        <div style="color: red;">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('dokter.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div>
            <label for="doctor_code">Kode Dokter</label><br>
            <input
                type="text"
                id="doctor_code"
                name="doctor_code"
                value="<?php echo e(old('doctor_code')); ?>"
                required
            >
        </div>

        <br>

        <div>
            <label for="name">Nama Dokter</label><br>
            <input
                type="text"
                id="name"
                name="name"
                value="<?php echo e(old('name')); ?>"
                required
            >
        </div>

        <br>

        <div>
            <label for="specialization">Spesialisasi</label><br>
            <input
                type="text"
                id="specialization"
                name="specialization"
                value="<?php echo e(old('specialization')); ?>"
                required
            >
        </div>

        <br>

        <div>
            <label for="phone">Telepon</label><br>
            <input
                type="text"
                id="phone"
                name="phone"
                value="<?php echo e(old('phone')); ?>"
            >
        </div>

        <br>

        <div>
            <label for="poli_id">Poli</label><br>
            <select id="poli_id" name="poli_id" required>
                <option value="">-- Pilih Poli --</option>

                <?php $__currentLoopData = $polis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option
                        value="<?php echo e($poli->id); ?>"
                        <?php echo e(old('poli_id') == $poli->id ? 'selected' : ''); ?>

                    >
                        <?php echo e($poli->code); ?> - <?php echo e($poli->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <br>

        <div>
            <label for="is_active">Status</label><br>
            <select id="is_active" name="is_active" required>
                <option value="1" <?php echo e(old('is_active', '1') == '1' ? 'selected' : ''); ?>>
                    Aktif
                </option>
                <option value="0" <?php echo e(old('is_active') === '0' ? 'selected' : ''); ?>>
                    Tidak Aktif
                </option>
            </select>
        </div>

        <br>

        <button type="submit">Simpan Dokter</button>
        <a href="<?php echo e(route('dokter.index')); ?>">Batal</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\THINKPAD\klinik-app\resources\views/dokter/create.blade.php ENDPATH**/ ?>