


<?php $__env->startSection('title', 'Pasien'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Data Pasien</h1>
    <p>Selamat datang di Sistem Informasi Klinik.</p>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <a href="<?php echo e(route('pasien.create')); ?>" class="btn btn-primary mb-3">
        Tambah Pasien
    </a>

    <p>Jumlah Pasien: <?php echo e($jumlahPasien); ?></p>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No.</th>
                <th>No. Rekam Medis</th>
                <th>Nama</th>
                <th>Jenis Kelamin</th>
                <th>Tanggal Lahir</th>
                <th>Alamat</th>
                <th>Telepon</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($patient->medical_record_number); ?></td>
                    <td><?php echo e($patient->name); ?></td>
                    <td><?php echo e($patient->gender); ?></td>
                    <td><?php echo e($patient->birth_date); ?></td>
                    <td><?php echo e($patient->address); ?></td>
                    <td><?php echo e($patient->phone); ?></td>
                    <td>
                        <a href="<?php echo e(route('pasien.edit', $patient->id)); ?>"
                           class="btn btn-warning btn-sm">
                            Edit
                        </a>

                        <form action="<?php echo e(route('pasien.destroy', $patient->id)); ?>"
                              method="POST"
                              style="display:inline;"
                              onsubmit="return confirm('Yakin ingin menghapus data pasien ini?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <button type="submit" class="btn btn-danger btn-sm">
                                Hapus
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center">
                        Belum ada data pasien.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\THINKPAD\klinik-app\resources\views/pasien/index.blade.php ENDPATH**/ ?>